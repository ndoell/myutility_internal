# myutility_internal

This is simple code used to demonstrate package confusion.
