from src.myutil import *

def test_sum():
    assert sum((8, 2, 3, 0, 7)) == 20
